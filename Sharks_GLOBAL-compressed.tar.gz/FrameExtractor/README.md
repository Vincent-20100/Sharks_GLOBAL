# FrameExtractor
A utility application for extracting frames from videos

##How to prepare
* install opencv* packages
* install python-opencv
* install python-numpy
* install python

##How to use
In the terminal write
"python extract.py destination_directory (list of files)"

# Cropping
A utility application to crop an image given some coordinates

##How to prepare
* See instructions for FrameExtractor

##How to use
In the terminal write
"python crop.py destination_directory image_file x y width height"
