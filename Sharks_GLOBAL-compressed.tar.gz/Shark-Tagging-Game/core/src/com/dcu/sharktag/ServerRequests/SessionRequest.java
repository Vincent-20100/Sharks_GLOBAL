package com.dcu.sharktag.ServerRequests;

public class SessionRequest {
	
	private String token;
	
	public SessionRequest(String token){
		this.token = token;
	}
}
