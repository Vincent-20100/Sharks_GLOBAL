package com.dcu.sharktag.ServerRequests;

public class ImageRequest {
	private String token;
	
	public ImageRequest(String token) {
		this.token = token;
	}
}
